# Drag and drop to widget:

| Widgets / Features | Bar | Line | Trend-diff | Tabular | Billboard | Solid Gauge | Sankey  | Geo Map
|--------------------|-----|------|------------|---------|-----------|-------------|---------|---------|
| Drop measure from sidebar | add measure & update relationship | add measure | replace measure & rename | add measure & add column | replace measure & rename | replace measure & rename | not supported | replace measure & rename
| Drop instance from sidebar | add instance | add instance | replace instance & rename | add instance | replace instance & rename | replace instance & rename | not supported | add instance & rename
| Drop both instance and measure from other widget | add instance | add both | replace both & rename instance | add instance | replace instance & rename | replace instance & rename | not supported | add instance & rename
