# Joulica Reporting Dashboard

This project was generated and ejected with [Angular CLI](https://github.com/angular/angular-cli) version 1.7.4.

## Development server

Client dev server: Run `npm start`. Navigate to `http://localhost:4200/`.

Sample json-server: `npm run start:backend:sample`

Sample real time server: `npm run watch-server`

Start all above: `npm run watch`

Above commands will use localhost for REST requests and connect to external websocket for data.  External websocket endpoint is defined in AppConfig.json.
To connect to local mock websocket set useFakeData to true in environment.ts.

## Build

Production build: `npm run build`

## Running unit tests

Run `npm test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Generate Code coverage report

Run `npm run coverage` to execute the unit tests and create the LCOV report for SonarQube.
To upload the code coverage report, run the local `sonar-scanner.sh` script. 
*Note: you will first need to install Sonar Scanner on your local development enviroment.* 

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


## Kubernetes Deployment

NOTE: USE THE ROLLOUT SCRIPT ./rolloutDashboard.sh
You can use the following as well, but first you need to export variables in your environment
 - export DOCKER_REPO="yyz.ocir.io" (or other docker registry to push/pull from)
 - export KUBERNETES_REPORTING_NAMESPACE="default"


1. Build a production release: Delete dist directory (if exists `rm -rf dist/`) and run `npm run build`
2. Build the docker image: `docker-compose -f deploy/docker-compose.yml build`
3. Login to Oracle Cloud: `docker login fra.ocir.io -u joulica/oracleidentitycloudservice/<YOUR-NAME>@joulica.io -p <YOUR-SECRET>`
4. Push the docker image: `docker-compose -f deploy/docker-compose.yml push`
5. Select Kubernetes context e.g. for Oracle Cloud: `kubectl config use-context bmcs-k8s-context`
6. Create the configmap for access to backend: `kubectl apply -f deploy/configmap.yml`. To verify: `kubectl get configmap dashboard-config -o yaml`
7. Delete the dashbaord deployment: `kubectl delete deployment joulica-reporting-dashboard`
7. Create the deployment in Kubernetes: `kubectl apply -f deploy/deployment.yml`
8. (OPTIONAL) If the service definition changes: `kubectl apply -f deploy/service.yml` NOTE: This will re-create the Load Balaner IP address.
