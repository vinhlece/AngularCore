import {Component} from '@angular/core';

@Component({
  selector: 'app-time-explorer-wrapper',
  templateUrl: './time-explorer-wrapper.container.html',
  styleUrls: ['./time-explorer-wrapper.container.scss']
})
export class TimeExplorerWrapperContainer {
}
