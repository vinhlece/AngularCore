import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ThemeService } from '../../../theme/theme.service';
import { Theme } from '../../../theme/model/index';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { User } from '../../../user/models/user';
import { Dashboard } from '../../../dashboard/models';
import { Store, select } from '@ngrx/store';
import * as fromUsers from '../../../user/reducers/index';
import * as userActions from '../../../user/actions/user.actions';
import * as dashboardActions from '../../../dashboard/actions/dashboards.action';
import * as _ from 'lodash';

@Component({
  selector: 'app-share-dialog',
  templateUrl: './share-dialog.component.html',
  styleUrls: ['./share-dialog.component.scss'],
})
export class ShareDialogComponent implements OnInit {
  formGroup: FormGroup;
  selectedUsers: string[];
  users: User[] = [];
  filterUsers: User[] = [];
  dashboard: Dashboard;

  constructor(public store: Store<fromUsers.State>, public dialogRef: MatDialogRef<ShareDialogComponent>, public translate: TranslateService,
    private themeService: ThemeService, public fb: FormBuilder, @Inject(MAT_DIALOG_DATA) data) {
    this.dashboard = data.dashboard;
  }

  ngOnInit() {
    const _this = this;
    this.formGroup = this.fb.group({
      name: this.fb.control([]),
      users: this.fb.control([])
    });
    // Trigger load shared dashboards
    this.store.dispatch(new userActions.LoadAll());

    this.store.pipe(select(fromUsers.getAllUsers)).subscribe((users: User[]) => this.filterUsers = this.users = users);

    // Trigger whenever user change selections
    this.formGroup.valueChanges.subscribe(value => {
      // Filter data before merge into current selected
      const userFilterIds = this.filterUsers.map(user => user.id);
      const diffValues = _.difference(_this.selectedUsers, userFilterIds);
      _this.selectedUsers = _.union(diffValues, value.users);
    });
  }

  onSave() {
    this.dialogRef.close();
    this.selectedUsers.forEach(selectedUserID => {
      const dashboard: Dashboard = { ...this.dashboard, cloneBy: selectedUserID };
      this.store.dispatch(new dashboardActions.Copy(dashboard));
    });
  }

  onCancel() {
    this.dialogRef.close();
  }

  isDarkTheme() {
    return this.themeService.getCurrentTheme() === Theme.Dark;
  }

  selectAll(event) {
    if (event.checked) {
      this.selectedUsers = this.filterUsers.map(user => user.id);
    } else {
      const userIds = this.users.map(user => user.id);
      const userFilterIds = this.filterUsers.map(user => user.id);
      this.selectedUsers = _.difference(userIds, userFilterIds);
    }
    this.formGroup.controls['users'].setValue(this.selectedUsers);
  }

  onSearchChange(event) {
    // Filter data by search keyword
    const searchName = event.target.value.trim();
    this.filterUsers = this.users.filter(user => user.displayName.includes(searchName));
    this.formGroup.controls['users'].setValue(this.selectedUsers);
  }
}