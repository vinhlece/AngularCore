export const COLUMNS_OF_ROW: number = 12;
