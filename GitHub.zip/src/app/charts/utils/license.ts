import {LicenseManager} from 'ag-grid-enterprise';

export function setAgGridLicense() {
  LicenseManager.setLicenseKey('Joulica__Time_Explorer_1Devs29_November_2019__MTU3NDk4NTYwMDAwMA==fc3a9fd45c39b2bf1252a71d43b819ae');
}
