export const chartBG = '#27293d';
export const chartText = '#CCC'
