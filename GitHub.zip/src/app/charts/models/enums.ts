export enum xAxisUnit {
  Day = 'Day',
  Time = 'Time',
}
