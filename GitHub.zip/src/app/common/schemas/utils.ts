export const createMeasureId = (dataType: string, measureName: string) => {
  return `${dataType}_${measureName}`;
};
