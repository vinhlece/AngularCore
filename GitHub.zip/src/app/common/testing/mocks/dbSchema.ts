export interface DbSchema {
  [key: string]: any;
}
