export enum KeyCodes {
  Enter = 13,
  Comma = 188,
  Space = 32,
}
