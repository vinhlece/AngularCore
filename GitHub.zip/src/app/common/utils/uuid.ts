import * as uuidv4 from 'uuid/v4';

export function uuid(): string {
  return uuidv4();
}
