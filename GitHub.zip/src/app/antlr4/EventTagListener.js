// Generated from D:/Working/Julica/ReportingWidget/src/app/antlr4\EventTag.g4 by ANTLR 4.7.2
// jshint ignore: start
var antlr4 = require('antlr4/index');

// This class defines a complete listener for a parse tree produced by EventTagParser.
function EventTagListener() {
	antlr4.tree.ParseTreeListener.call(this);
	return this;
}

EventTagListener.prototype = Object.create(antlr4.tree.ParseTreeListener.prototype);
EventTagListener.prototype.constructor = EventTagListener;

// Enter a parse tree produced by EventTagParser#main.
EventTagListener.prototype.enterMain = function(ctx) {
};

// Exit a parse tree produced by EventTagParser#main.
EventTagListener.prototype.exitMain = function(ctx) {
};


// Enter a parse tree produced by EventTagParser#BasicExpr.
EventTagListener.prototype.enterBasicExpr = function(ctx) {
};

// Exit a parse tree produced by EventTagParser#BasicExpr.
EventTagListener.prototype.exitBasicExpr = function(ctx) {
};


// Enter a parse tree produced by EventTagParser#BasicOp.
EventTagListener.prototype.enterBasicOp = function(ctx) {
};

// Exit a parse tree produced by EventTagParser#BasicOp.
EventTagListener.prototype.exitBasicOp = function(ctx) {
};


// Enter a parse tree produced by EventTagParser#AddOp.
EventTagListener.prototype.enterAddOp = function(ctx) {
};

// Exit a parse tree produced by EventTagParser#AddOp.
EventTagListener.prototype.exitAddOp = function(ctx) {
};



exports.EventTagListener = EventTagListener;