// Generated from D:/Working/Julica/ReportingWidget/src/app/antlr4\EventTag.g4 by ANTLR 4.7.2
// jshint ignore: start
var antlr4 = require('antlr4/index');



var serializedATN = ["\u0003\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964",
    "\u0002\ns\b\u0001\u0004\u0002\t\u0002\u0004\u0003\t\u0003\u0004\u0004",
    "\t\u0004\u0004\u0005\t\u0005\u0004\u0006\t\u0006\u0004\u0007\t\u0007",
    "\u0004\b\t\b\u0004\t\t\t\u0004\n\t\n\u0004\u000b\t\u000b\u0004\f\t\f",
    "\u0004\r\t\r\u0004\u000e\t\u000e\u0004\u000f\t\u000f\u0003\u0002\u0003",
    "\u0002\u0003\u0002\u0003\u0002\u0003\u0003\u0003\u0003\u0003\u0004\u0003",
    "\u0004\u0003\u0004\u0003\u0005\u0005\u0005*\n\u0005\u0003\u0005\u0003",
    "\u0005\u0003\u0005\u0006\u0005/\n\u0005\r\u0005\u000e\u00050\u0005\u0005",
    "3\n\u0005\u0003\u0005\u0005\u00056\n\u0005\u0003\u0006\u0003\u0006\u0007",
    "\u0006:\n\u0006\f\u0006\u000e\u0006=\u000b\u0006\u0003\u0007\u0003\u0007",
    "\u0003\u0007\u0007\u0007B\n\u0007\f\u0007\u000e\u0007E\u000b\u0007\u0003",
    "\u0007\u0003\u0007\u0003\b\u0003\b\u0003\b\u0007\bL\n\b\f\b\u000e\b",
    "O\u000b\b\u0005\bQ\n\b\u0003\t\u0003\t\u0005\tU\n\t\u0003\t\u0003\t",
    "\u0003\n\u0003\n\u0003\n\u0005\n\\\n\n\u0003\u000b\u0003\u000b\u0003",
    "\u000b\u0003\u000b\u0003\u000b\u0003\u000b\u0003\f\u0003\f\u0003\r\u0003",
    "\r\u0003\u000e\u0005\u000ei\n\u000e\u0003\u000e\u0003\u000e\u0003\u000f",
    "\u0006\u000fn\n\u000f\r\u000f\u000e\u000fo\u0003\u000f\u0003\u000f\u0002",
    "\u0002\u0010\u0003\u0003\u0005\u0004\u0007\u0005\t\u0006\u000b\u0007",
    "\r\b\u000f\u0002\u0011\u0002\u0013\u0002\u0015\u0002\u0017\u0002\u0019",
    "\u0002\u001b\t\u001d\n\u0003\u0002\u000f\u0004\u0002CCcc\u0004\u0002",
    "PPpp\u0004\u0002FFff\u0003\u00022;\u0004\u0002C\\c|\u0005\u00022;C\\",
    "c|\u0003\u00023;\u0004\u0002GGgg\u0004\u0002--//\n\u0002$$11^^ddhhp",
    "pttvv\u0005\u00022;CHch\u0005\u0002\u0002!$$^^\u0004\u0002\u000b\u000b",
    "\"\"\u0002y\u0002\u0003\u0003\u0002\u0002\u0002\u0002\u0005\u0003\u0002",
    "\u0002\u0002\u0002\u0007\u0003\u0002\u0002\u0002\u0002\t\u0003\u0002",
    "\u0002\u0002\u0002\u000b\u0003\u0002\u0002\u0002\u0002\r\u0003\u0002",
    "\u0002\u0002\u0002\u001b\u0003\u0002\u0002\u0002\u0002\u001d\u0003\u0002",
    "\u0002\u0002\u0003\u001f\u0003\u0002\u0002\u0002\u0005#\u0003\u0002",
    "\u0002\u0002\u0007%\u0003\u0002\u0002\u0002\t)\u0003\u0002\u0002\u0002",
    "\u000b7\u0003\u0002\u0002\u0002\r>\u0003\u0002\u0002\u0002\u000fP\u0003",
    "\u0002\u0002\u0002\u0011R\u0003\u0002\u0002\u0002\u0013X\u0003\u0002",
    "\u0002\u0002\u0015]\u0003\u0002\u0002\u0002\u0017c\u0003\u0002\u0002",
    "\u0002\u0019e\u0003\u0002\u0002\u0002\u001bh\u0003\u0002\u0002\u0002",
    "\u001dm\u0003\u0002\u0002\u0002\u001f \t\u0002\u0002\u0002 !\t\u0003",
    "\u0002\u0002!\"\t\u0004\u0002\u0002\"\u0004\u0003\u0002\u0002\u0002",
    "#$\u0007?\u0002\u0002$\u0006\u0003\u0002\u0002\u0002%&\u0007#\u0002",
    "\u0002&\'\u0007?\u0002\u0002\'\b\u0003\u0002\u0002\u0002(*\u0007/\u0002",
    "\u0002)(\u0003\u0002\u0002\u0002)*\u0003\u0002\u0002\u0002*+\u0003\u0002",
    "\u0002\u0002+2\u0005\u000f\b\u0002,.\u00070\u0002\u0002-/\t\u0005\u0002",
    "\u0002.-\u0003\u0002\u0002\u0002/0\u0003\u0002\u0002\u00020.\u0003\u0002",
    "\u0002\u000201\u0003\u0002\u0002\u000213\u0003\u0002\u0002\u00022,\u0003",
    "\u0002\u0002\u000223\u0003\u0002\u0002\u000235\u0003\u0002\u0002\u0002",
    "46\u0005\u0011\t\u000254\u0003\u0002\u0002\u000256\u0003\u0002\u0002",
    "\u00026\n\u0003\u0002\u0002\u00027;\t\u0006\u0002\u00028:\t\u0007\u0002",
    "\u000298\u0003\u0002\u0002\u0002:=\u0003\u0002\u0002\u0002;9\u0003\u0002",
    "\u0002\u0002;<\u0003\u0002\u0002\u0002<\f\u0003\u0002\u0002\u0002=;",
    "\u0003\u0002\u0002\u0002>C\u0007$\u0002\u0002?B\u0005\u0013\n\u0002",
    "@B\u0005\u0019\r\u0002A?\u0003\u0002\u0002\u0002A@\u0003\u0002\u0002",
    "\u0002BE\u0003\u0002\u0002\u0002CA\u0003\u0002\u0002\u0002CD\u0003\u0002",
    "\u0002\u0002DF\u0003\u0002\u0002\u0002EC\u0003\u0002\u0002\u0002FG\u0007",
    "$\u0002\u0002G\u000e\u0003\u0002\u0002\u0002HQ\u00072\u0002\u0002IM",
    "\t\b\u0002\u0002JL\t\u0005\u0002\u0002KJ\u0003\u0002\u0002\u0002LO\u0003",
    "\u0002\u0002\u0002MK\u0003\u0002\u0002\u0002MN\u0003\u0002\u0002\u0002",
    "NQ\u0003\u0002\u0002\u0002OM\u0003\u0002\u0002\u0002PH\u0003\u0002\u0002",
    "\u0002PI\u0003\u0002\u0002\u0002Q\u0010\u0003\u0002\u0002\u0002RT\t",
    "\t\u0002\u0002SU\t\n\u0002\u0002TS\u0003\u0002\u0002\u0002TU\u0003\u0002",
    "\u0002\u0002UV\u0003\u0002\u0002\u0002VW\u0005\u000f\b\u0002W\u0012",
    "\u0003\u0002\u0002\u0002X[\u0007^\u0002\u0002Y\\\t\u000b\u0002\u0002",
    "Z\\\u0005\u0015\u000b\u0002[Y\u0003\u0002\u0002\u0002[Z\u0003\u0002",
    "\u0002\u0002\\\u0014\u0003\u0002\u0002\u0002]^\u0007w\u0002\u0002^_",
    "\u0005\u0017\f\u0002_`\u0005\u0017\f\u0002`a\u0005\u0017\f\u0002ab\u0005",
    "\u0017\f\u0002b\u0016\u0003\u0002\u0002\u0002cd\t\f\u0002\u0002d\u0018",
    "\u0003\u0002\u0002\u0002ef\n\r\u0002\u0002f\u001a\u0003\u0002\u0002",
    "\u0002gi\u0007\u000f\u0002\u0002hg\u0003\u0002\u0002\u0002hi\u0003\u0002",
    "\u0002\u0002ij\u0003\u0002\u0002\u0002jk\u0007\f\u0002\u0002k\u001c",
    "\u0003\u0002\u0002\u0002ln\t\u000e\u0002\u0002ml\u0003\u0002\u0002\u0002",
    "no\u0003\u0002\u0002\u0002om\u0003\u0002\u0002\u0002op\u0003\u0002\u0002",
    "\u0002pq\u0003\u0002\u0002\u0002qr\b\u000f\u0002\u0002r\u001e\u0003",
    "\u0002\u0002\u0002\u0010\u0002)025;ACMPT[ho\u0003\b\u0002\u0002"].join("");


var atn = new antlr4.atn.ATNDeserializer().deserialize(serializedATN);

var decisionsToDFA = atn.decisionToState.map( function(ds, index) { return new antlr4.dfa.DFA(ds, index); });

function EventTagLexer(input) {
	antlr4.Lexer.call(this, input);
    this._interp = new antlr4.atn.LexerATNSimulator(this, atn, decisionsToDFA, new antlr4.PredictionContextCache());
    return this;
}

EventTagLexer.prototype = Object.create(antlr4.Lexer.prototype);
EventTagLexer.prototype.constructor = EventTagLexer;

Object.defineProperty(EventTagLexer.prototype, "atn", {
        get : function() {
                return atn;
        }
});

EventTagLexer.EOF = antlr4.Token.EOF;
EventTagLexer.AND = 1;
EventTagLexer.EQUAL = 2;
EventTagLexer.NOTEQUAL = 3;
EventTagLexer.NUMBER = 4;
EventTagLexer.ID = 5;
EventTagLexer.STRING = 6;
EventTagLexer.NEWLINE = 7;
EventTagLexer.WS = 8;

EventTagLexer.prototype.channelNames = [ "DEFAULT_TOKEN_CHANNEL", "HIDDEN" ];

EventTagLexer.prototype.modeNames = [ "DEFAULT_MODE" ];

EventTagLexer.prototype.literalNames = [ null, null, "'='", "'!='" ];

EventTagLexer.prototype.symbolicNames = [ null, "AND", "EQUAL", "NOTEQUAL", 
                                          "NUMBER", "ID", "STRING", "NEWLINE", 
                                          "WS" ];

EventTagLexer.prototype.ruleNames = [ "AND", "EQUAL", "NOTEQUAL", "NUMBER", 
                                      "ID", "STRING", "INT", "EXP", "ESC", 
                                      "UNICODE", "HEX", "SAFECODEPOINT", 
                                      "NEWLINE", "WS" ];

EventTagLexer.prototype.grammarFileName = "EventTag.g4";



exports.EventTagLexer = EventTagLexer;

