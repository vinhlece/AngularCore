#!/bin/bash
node $@